echo "Hello World"
python -m pip install --upgrade pip
 pip install flask
 pip install flask_sqlalchemy
 pip install datetime
python app.py